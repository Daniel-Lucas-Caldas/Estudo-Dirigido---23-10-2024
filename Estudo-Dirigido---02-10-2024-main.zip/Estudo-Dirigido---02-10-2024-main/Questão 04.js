// Turma 88433 - Senai Dendezeiros
// Alunos: Daniel Lucas e Kauan Nascimento

// Arrays de nomes
const nomes1 = ['João', 'Maria', 'Lucas', 'André'];
const nomes2 = ['Pedro', 'Ana', 'Joana', 'Milena', 'Giulia'];

// Função para concatenar os dois arrays
const nomesConcatenados = nomes1.concat(nomes2);

// Exibindo o resultado
console.log(nomesConcatenados);
