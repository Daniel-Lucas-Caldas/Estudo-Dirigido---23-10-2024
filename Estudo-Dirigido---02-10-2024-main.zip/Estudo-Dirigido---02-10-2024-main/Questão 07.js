// Turma 88433 - Senai Dendezeiros
// Alunos: Daniel Lucas e Kauan Nascimento

// Array original
const letras = ['a', 'b', 'c', 'd', 'e', 'f'];

// Função para inverter o array
const letrasInvertidas = letras.reverse();

// Exibindo o resultado
console.log(letrasInvertidas);
